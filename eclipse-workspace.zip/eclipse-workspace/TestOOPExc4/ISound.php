<?php

interface ISound
{
    function soundAnimal();
}

