<?php

class Frog extends Animal
{

    public function __construct()
    {
        parent::__construct();
    }
    
    public function soundAnimal()
    {
        return "Op Op Op!";
    }

}

