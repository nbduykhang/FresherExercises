<?php

abstract class Animal implements ISound
{
    protected $age;
    protected $name;
    protected $sex;
    public function __construct()
    {}
    public function __construct($age,$name,$sex){
        $this->age=$age;
        $this->name=$name;
        $this->sex=$sex;
    }
    /**
     * @return mixed
     */
    public function getAge()
    {
        return $this->age;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @return mixed
     */
    public function getSex()
    {
        return $this->sex;
    }

    /**
     * @param mixed $age
     */
    public function setAge($age)
    {
        $this->age = $age;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @param mixed $sex
     */
    public function setSex($sex)
    {
        $this->sex = $sex;
    }
    static public function addList($arr=array(),$param){
        $arr[]=$param;
    }
    static public function averageAge($arr=[]) {
        $sumAge=0;
        $avgAge=0;
        for($i=0; $i<=count($arr); $i++){
            $sumAge += $arr[$i];
        }
        $avgAge=$sumAge/count($arr);
        return $avgAge;
    }
}

