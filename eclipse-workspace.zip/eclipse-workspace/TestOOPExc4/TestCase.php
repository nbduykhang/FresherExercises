<?php
$cat1 = new Cat(1, "mimi", "Female");
$cat2 = new Cat(2, "mon", "Male");
$cat3 = new Cat(3, "mun", "Male");
$kitten = new Kitten(5, "fanny");
$tomcat = new Tomcat(7, "bigboss");

$arrCats = array();
Cat::addList($arrCats,$cat1->getAge());
Cat::addList($arrCats,$cat2->getAge());
Cat::addList($arrCats,$cat3->getAge());
Cat::addList($arrCats,$kitten->getAge());
Cat::addList($arrCats,$tomcat->getAge());

$avgAgeCat=Cat::averageAge($arrCats);
echo $avgAgeCat;

$dog1 = new Dog(5, "lyly", "Female");
$dog2 = new Dog(8, "lulu", "Male");
$dog3 = new Dog(4, "bull", "Male");

$arrDogs = array();
Dog::addList($arrDogs,$dog1->getAge());
Dog::addList($arrDogs,$dog2->getAge());
Dog::addList($arrDogs,$dog3->getAge());

$avgAgeDog=Dog::averageAge($arrDogs);
echo $avgAgeDog;

$frog1 = new Dog(2, "tic", "Female");
$frog2 = new Dog(9, "toc", "Female");
$frog3 = new Dog(15, "toe", "Male");

$arrFrogs = array();
Frog::addList($arrFrogs,$frog1->getAge());
Frog::addList($arrFrogs,$frog2->getAge());
Frog::addList($arrFrogs,$frog3->getAge());

$avgAgeFrog=Frog::averageAge($arrFrogs);
echo $avgAgeFrog;

