<?php

class Kitten extends Cat
{
    private $sex="Female";
    public function __construct()
    {
        parent::__construct();
    }
    public function __construct($age,$name){
        parent::__construct($this->age,$this->name,$this->sex);
        $this->name=$name;
        $this->age=$age;
    }
    public function getSex(){
        return $this->sex;
    }
}

