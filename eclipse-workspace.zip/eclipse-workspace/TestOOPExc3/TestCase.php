<?php
$arrStudent=array();
$student=new Student();
$student->setFirstName("A");
$student->setLastName("Nguyen Van");
$student->setGrade(1);
$arrStudent[]=$student;

$student1=new Student();
$student1->setFirstName("B");
$student1->setLastName("Nguyen Van");
$student1->setGrade(2);
$arrStudent[]=$student1;

$student2=new Student();
$student2->setFirstName("C");
$student2->setLastName("Nguyen Van");
$student2->setGrade(3);
$arrStudent[]=$student2;

$student3=new Student();
$student3->setFirstName("D");
$student3->setLastName("Nguyen Van");
$student3->setGrade(4);
$arrStudent[]=$student3;

$student4=new Student();
$student4->setFirstName("E");
$student4->setLastName("Nguyen Van");
$student4->setGrade(5);
$arrStudent[]=$student4;

$student5=new Student();
$student5->setFirstName("F");
$student5->setLastName("Nguyen Van");
$student5->setGrade(6);
$arrStudent[]=$student5;

$student6=new Student();
$student6->setFirstName("G");
$student6->setLastName("Nguyen Van");
$student6->setGrade(7);
$arrStudent[]=$student6;

$student7=new Student();
$student7->setFirstName("H");
$student7->setLastName("Nguyen Van");
$student7->setGrade(8);
$arrStudent[]=$student7;

$student8=new Student();
$student8->setFirstName("I");
$student8->setLastName("Nguyen Van");
$student8->setGrade(9);
$arrStudent[]=$student8;

$student9=new Student();
$student9->setFirstName("J");
$student9->setLastName("Nguyen Van");
$student9->setGrade(10);
$arrStudent[]=$student9;



$arrWorker=array();
$worker=new Worker(2000000, 8);
$worker->setFirstName("A1");
$worker->setLastName("Le Van");
$arrWorker[]=$worker;

$worker1=new Worker(3000000, 10);
$worker1->setFirstName("B1");
$worker1->setLastName("Le Van");
$arrWorker[]=$worker1;

$worker2=new Worker(4000000, 7);
$worker2->setFirstName("C1");
$worker2->setLastName("Le Van");
$arrWorker[]=$worker2;

$worker3=new Worker(5000000, 8);
$worker3->setFirstName("D1");
$worker3->setLastName("Le Van");
$arrWorker[]=$worker3;

$worker4=new Worker(1000000, 8);
$worker4->setFirstName("E1");
$worker4->setLastName("Le Van");
$arrWorker[]=$worker4;

$worker5=new Worker(6000000, 8);
$worker5->setFirstName("F1");
$worker5->setLastName("Le Van");
$arrWorker[]=$worker5;

$worker6=new Worker(7000000, 8);
$worker6->setFirstName("G1");
$worker6->setLastName("Le Van");
$arrWorker[]=$worker6;

$worker7=new Worker(8000000, 8);
$worker7->setFirstName("H1");
$worker7->setLastName("Le Van");
$arrWorker[]=$worker7;

$worker8=new Worker(9000000, 8);
$worker8->setFirstName("I1");
$worker8->setLastName("Le Van");
$arrWorker[]=$worker8;

$worker9=new Worker(10000000, 8);
$worker9->setFirstName("J1");
$worker9->setLastName("Le Van");
$arrWorker[]=$worker9;

for($i=0; $i<9; $i++){
    for($j=$i+1; $j<=9; $j++){
        if($arrStudent[$i]->getGrade()>$arrStudent[$j]->getGrade()){
            $temp = $arrStudent[$i];
            $arrStudent[$i]=$arrStudent[$j];
            $arrStudent[$j]=$temp;
        }
        if($arrWorker[$i]->moneyPerHour()<$arrWorker[$j]->moneyPerHour()){
            $temp1 = $arrWorker[$i];
            $arrWorker[$i]=$arrWorker[$j];
            $arrWorker[$j]=$temp1;
        }
    }
}
echo $arrStudent,$arrWorker;

$arrMerged=array();
$arrMerged=array_merge($arrStudent,$arrWorker);
sort($arrMerged);