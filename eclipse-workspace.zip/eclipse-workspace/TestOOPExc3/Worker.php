<?php

class Worker extends Human
{
    private $weekSalary;
    private $workHoursPerDay;
    public function __construct($weekSalary,$workHoursPerDay)
    {
        parent::__construct($this->firstName, $this->lastName);
        $this->weekSalary=$weekSalary;
        $this->workHoursPerDay=$workHoursPerDay;
    }
    public function __construct(){}
    public function setLastName($lastName)
    {
        $this->lastName=$lastName;
    }

    public function setFirstName($firstName)
    {
        $this->firstName=$firstName;
    }

    public function getFirstName()
    {
        return $this->firstName;
    }

    public function getLastName()
    {
        return $this->lastName;
    }
    
    public function moneyPerHour(){
        $money=($this->weekSalary / 7) / $this->workHoursPerDay;
        return $money;
    }
}

