<?php

abstract class Human
{
    protected $firstName;
    protected $lastName;
    /**
     * @return mixed
     */
    abstract public function getFirstName();

    /**
     * @return mixed
     */
    abstract public function getLastName();

    /**
     * @param mixed $firstName
     */
    abstract public function setFirstName($firstName);

    /**
     * @param mixed $lastName
     */
    abstract public function setLastName($lastName);

    public function __construct($firstName,$lastName)
    {
        $this->firstName=$firstName;
        $this->lastName=$lastName;
    }
    
}

