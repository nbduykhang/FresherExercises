<?php

class Student extends Human
{
    private $grade;
    public function __construct($grade)
    {
        parent::__construct($this->firstName,$this->lastName);
        $this->grade=$grade;
    }
    public function __construct()
    {    }
    public function setLastName($lastName)
    {
       $this->lastName=$lastName;
    }

    public function setFirstName($firstName)
    {
        $this->firstName=$firstName;
    }

    public function getFirstName()
    {
        return $this->firstName;
    }

    public function getLastName()
    {
        return $this->lastName;
    }
    /**
     * @return mixed
     */
    public function getGrade()
    {
        return $this->grade;
    }

    /**
     * @param mixed $grade
     */
    public function setGrade($grade)
    {
        $this->grade = $grade;
    }

    public function sortGrade($arr=array()){
        for($i=0; $i<9; $i++){
            for($j=$i+1; $j<=9; $j++){
                if($arr[$i]<$arr[$j]){
                    $temp = $arr[$i];
                    $arr[$i]=$arr[$j];
                    $arr[$j]=$temp;
                }
            }
        }
        return $arr;
    }
    

}

