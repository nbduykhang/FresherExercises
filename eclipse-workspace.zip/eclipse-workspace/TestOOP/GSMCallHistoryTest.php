<?php
class GSMCallHistoryTest {
    function test() {
        
        $callHistory1=new Call();
        $callHistory1->setIdCall(1);
        $callHistory1->setDate("25/2/2019");
        $callHistory1->setTime("17h00");
        $callHistory1->setDialedPhoneNum("0987654321");
        $callHistory1->setDuration(5);
        echo $callHistory1->totalPrice();
        
        $callHistory2=new Call();
        $callHistory2->setIdCall(2);
        $callHistory2->setDate("28/2/2019");
        $callHistory2->setTime("16h00");
        $callHistory2->setDialedPhoneNum("0934567891");
        $callHistory2->setDuration(10);
        echo $callHistory2->totalPrice();
        
        $gsm=new GSM();
        $gsm->addCall($callHistory1);
        $gsm->addCall($callHistory2);
        $gsm->deleteCall($callHistory1);
        
        $listCallHistory=[];
        $listCallHistory=$gsm->getCallHistory();
        foreach ($listCallHistory as $callHistory){
            var_dump($callHistory);
        }
        
    }
}