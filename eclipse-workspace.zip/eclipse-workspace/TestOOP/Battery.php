<?php

class Battery
{
    private $model;
    private $hoursIdle;
    private $hoursTalk;
    const BATTERY_TYPE_1 = 'Li-on';
    const BATTERY_TYPE_2 = 'NiMH';
    const BATTERY_TYPE_3 = 'NiCd';
    
    private static $batteryType = [];
    
    public static function getType(string $batteryTypeName): Battery
    {
        if (!isset(self::$batteryType[$batteryTypeName])) {
            self::$batteryType[$batteryTypeName] = new self();
        }
        
        return self::$batteryType[$batteryTypeName];
    }
    
    
    public function __construct(){
        
    }
    
    public function __construct($model,$hoursIdle,$hoursTalk)
    {
        $this->model=$model;
        $this->hoursIdle=$hoursIdle;
        $this->hoursTalk=$hoursTalk;
    }
    /**
     * @return mixed
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @return mixed
     */
    public function getHoursIdle()
    {
        return $this->hoursIdle;
    }

    /**
     * @return mixed
     */
    public function getHoursTalk()
    {
        return $this->hoursTalk;
    }

    /**
     * @param mixed $model
     */
    public function setModel($model)
    {
        $this->model = $model;
    }

    /**
     * @param mixed $hoursIdle
     */
    public function setHoursIdle($hoursIdle)
    {
        $this->hoursIdle = $hoursIdle;
    }

    /**
     * @param mixed $hoursTalk
     */
    public function setHoursTalk($hoursTalk)
    {
        $this->hoursTalk = $hoursTalk;
    }
    
    public function getBatteryType($type){
        return $this::BATTERY_TYPE[$type];
    }
}

