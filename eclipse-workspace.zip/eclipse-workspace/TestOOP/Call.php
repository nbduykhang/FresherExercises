<?php

class Call
{
    private $idCall;
    private $date;
    private $time;
    private $dialedPhoneNum;
    private $duration;

    public function __construct()
    {}
    
    
    /**
     * @return mixed
     */
    public function getIdCall()
    {
        return $this->idCall;
    }

    /**
     * @param mixed $idCall
     */
    public function setIdCall($idCall)
    {
        $this->idCall = $idCall;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @return mixed
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * @return mixed
     */
    public function getDialedPhoneNum()
    {
        return $this->dialedPhoneNum;
    }

    /**
     * @return mixed
     */
    public function getDuration()
    {
        return $this->duration;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @param mixed $time
     */
    public function setTime($time)
    {
        $this->time = $time;
    }

    /**
     * @param mixed $dialedPhoneNum
     */
    public function setDialedPhoneNum($dialedPhoneNum)
    {
        $this->dialedPhoneNum = $dialedPhoneNum;
    }

    /**
     * @param mixed $duration
     */
    public function setDuration($duration)
    {
        $this->duration = $duration;
    }
    
    public function totalPrice(){
        return $this->duration*0.37;
    }
    public function totalPrice($pricepermin){
        return $this->duration*$pricepermin;
    }
    public function __toString(){
        return "Datetime: ".$this->date."/".$this->time."--Phone Number: ".$this->dialedPhoneNum."--Duaration: ".$this->duration;
    }
}

