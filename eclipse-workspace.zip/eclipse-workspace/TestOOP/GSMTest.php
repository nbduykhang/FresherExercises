<?php
class GSMTest {
    function testCase() {
        $gsm=new GSM();
        $gsm->setModel("N8");
        $gsm->setManufacturer("Nokia");
        $gsm->setOwner("HMD Global");
        $gsm->setPrice(7000000);
        
        $battery= new Battery();
        $battery->setModel("B145");
        $battery->setHoursTalk(30);
        $battery->setHoursIdle(35);
        
        $battery1=new Battery();
        $battery1=$battery->getType("Li-on");
        
        $gsm->setModelBattery($battery->getModel());
        
        $display=new Display();
        $display->setId(1);
        $display->setSize(9);
        $display->setNumOfColors(3);
        
        $gsm->setIdDisplay($display->getId());
        
        $info=$gsm->__toString();
        echo $info;
        
        $ip4=GSM::IPhone4s($battery1, $display);
        echo $ip4->__toString();
    }
}

