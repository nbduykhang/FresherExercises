<?php

class GSM
{
    private $model;
    private $manufacturer;
    private $price;
    private $owner;
    private $modelBattery;
    private $idDisplay;
    private $callHistory = array();

    public function __construct($model,$manufacturer,$price,$owner,$battery,$display)
    {
        $this->model=$model;
        $this->manufacturer=$manufacturer;
        $this->price=$price;
        $this->owner=$owner;
        $this->modelBattery=$battery;
        $this->idDisplay=$display;
    }
    public function __construct(){
        
    }
    
    /**
     * @return mixed
     */
    public function getModelBattery()
    {
        return $this->modelBattery;
    }

    /**
     * @return mixed
     */
    public function getIdDisplay()
    {
        return $this->idDisplay;
    }

    /**
     * @param mixed $modelBattery
     */
    public function setModelBattery(Battery $battery)
    {
        $this->modelBattery = $battery->getModel();
    }

    /**
     * @param mixed $idDisplay
     */
    public function setIdDisplay(Display $display)
    {
        $this->idDisplay = $display->getId();
    }

    /**
     * @return mixed
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @return mixed
     */
    public function getManufacturer()
    {
        return $this->manufacturer;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @return mixed
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * @param mixed $model
     */
    public function setModel($model)
    {
        $this->model = $model;
    }

    /**
     * @param mixed $manufacturer
     */
    public function setManufacturer($manufacturer)
    {
        $this->manufacturer = $manufacturer;
    }

    /**
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @param mixed $owner
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;
    }

    
    public function __toString():string{
        return "Model: ".$this->model."/ "."Manufacturer: ".$this->manufacturer."/ "."Price: ".$this->price."/ "."Owner: ".$this->owner;
    }
    public static function IPhone4s(Battery $battery, Display $display):GSM{
        return new GSM("IP4", "IPhone4S", 1000, "Apple", $battery->getModel(), $display->getId());
    }
    public function addCall(Call $call){
        $this->callHistory[]=(array)$call;
    }
    public function deleteCall(Call $call){
        unset($this->callHistory[$call->getIdCall()]);
    }
    public function getCallHistory():array {
        return $this->callHistory;
    }
}

