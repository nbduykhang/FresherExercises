<?php

class Display
{
    private $id;

    private $size;

    private $numOfColors;
    
    public function __construct($size,$numOfColors){
        $this->size=$size;
        $this->numOfColors=$numOfColors;
    }

    /**
     *
     * @return mixed
     */
    public function __construct(){
        
    }
    
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    public function getSize()
    {
        return $this->size;
    }

    /**
     *
     * @return mixed
     */
    public function getNumOfColors()
    {
        return $this->numOfColors;
    }

    /**
     *
     * @param mixed $size
     */
    public function setSize($size)
    {
        $this->size = $size;
    }

    /**
     *
     * @param mixed $numOfColors
     */
    public function setNumOfColors($numOfColors)
    {
        $this->numOfColors = $numOfColors;
    }
}

