<?php
    $conn=new MyPDOConnect();
    $pdo=$conn->openConnection();
    $product1=new Product('Iphone XsMax', 'Product of Apple', 1100);
    $product2=new Product('Samsung Galaxy S10', 'Product of Samsung', 900);
    $product3=new Product('Nokia 9 Pureview', 'Product of HMD Global', 700);
    $product4=new Product('Huawei Mate20 Pro', 'Product of Huawei', 900);
    
    $productBUS= new ProductBUS();
    $productBUS->insert($conn, $product1);
    $productBUS->insert($conn, $product2);
    $productBUS->insert($conn, $product3);
    $productBUS->insert($conn, $product4);
    
    $listProducts=array();
    $listProducts=$productBUS->getAllData($conn);
    
    $listProCons=array();
    $condition='id > 1 and id < 4';
    $listProCons=$productBUS->getAllDataByWhere($conn,$condition);
    
    $productBUS->delete($conn, $product1->getId());
    $productBUS->delete($conn, $product2->getId());
    
    $product3->setPrice(699);
    $product4->setPrice(899);
    $productBUS->update($conn, $product3);
    $productBUS->update($conn, $product4);
    
    $product=new Product();
    if($_POST['name'] && $_POST['description'] && $_POST['price']){
        $product->setName($_POST['name']);
        $product->setName($_POST['description']);
        $product->setName($_POST['price']);
        $productBUS->insert($conn, $product);
    }
    $conn->closeConnection($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <a href=""><button class="btn btn-primary" style="margin-top: 10px;">Create New Product</button></a>     
  <table class="table table-bordered" style="margin-top: 10px;">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php
    foreach($listProducts as $productData){ ?>
      <tr>
        <td><?php echo $productData->getId(); ?></td>
        <td><?php echo $productData->getName(); ?></td>
        <td><?php echo $productData->getDescription(); ?></td>
        <td><?php echo $productData->getPrice(); ?></td>
        <td><a class="btn btn-info text-white">Read</a> <a href="" class="btn btn-primary">Edit</a> <a href="" class="btn btn-danger">Delete</a></td>
      </tr>
    <?php } ?>
      <tr>
        <td>2</td>
        <td>Moe</td>
        <td>mary@example.com</td>
        <td>10000000</td>
        <td><a class="btn btn-info text-white">Read</a> <a href="" class="btn btn-primary">Edit</a> <a href="" class="btn btn-danger">Delete</a></td>
      </tr>
      <tr>
        <td>3</td>
        <td>Dooley</td>
        <td>july@example.com</td>
        <td>15000000</td>
        <td><a class="btn btn-info text-white">Read</a> <a href="" class="btn btn-primary">Edit</a> <a href="" class="btn btn-danger">Delete</a></td>
      </tr>
    </tbody>
  </table>
  <form action = "" method = "POST">
    Name: <input type = "text" name = "name" />
    Description: <input type = "text" name = "Description" />
    Price: <input type="text" name="Price" />
    <input type = "submit" value="Insert Product" />
  </form>
</div>

</body>
</html>
