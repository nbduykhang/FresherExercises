<?php
require 'MyPDOConnect.php';
require 'Product.php';
class ProductDAO
{
    public function __construct()
    {}
    public function insert(MyPDOConnect $conn, Product $pd) {
        $db=$conn->openConnection();
        $insert_db=$db->prepare('INSERT INTO products (name, description, price) 
                                 VALUES (:name, :description, :price');
        $insert_db->bindParam(':name', $pd->getName());
        $insert_db->bindParam(':description', $pd->getDescription());
        $insert_db->bindParam(':price', $pd->getPrice());
        
        return $insert_db->execute();
    }
    public function update(MyPDOConnect $conn, Product $pd){
        $db=$conn->openConnection();
        $update_db=$db->prepare('UPDATE products 
                                 SET name=:name, description=:description, price=:price 
                                 WHERE id=:id');
        $update_db->bindParam(':id', $pd->getId());
        $update_db->bindParam(':name', $pd->getName());
        $update_db->bindParam(':description', $pd->getDescription());
        $update_db->bindParam(':price', $pd->getPrice());
        
        return $update_db->execute();
        
    }
    public function delete(MyPDOConnect $conn, $id) {
        $db=$conn->openConnection();
        $delete_db=$db->prepare('DELETE FROM products WHERE id=:id');
        $delete_db->bindParam(':id', $id);
        
        return $delete_db->execute(); 
    }
    public function getDataNotWhere(MyPDOConnect $conn, $propers=array()){
        $db=$conn->openConnection();
        $strPropers='';
        foreach ($propers as $proper){
            $strPropers.=$proper.',';
        }
        $getData=$db->prepare('SELECT '.$strPropers.' FROM products');
        return $getData->fetchAll();
    }
    public function getDataWhere(MyPDOConnect $conn, $propers=array(), $condition){
        $db=$conn->openConnection();
        $strPropers='';
        foreach ($propers as $proper){
            $strPropers.=$proper.',';
        }
        $getData=$db->prepare('SELECT '.$strPropers.' FROM products WHERE '.$condition);
        return $getData->fetchAll();
    }
}

