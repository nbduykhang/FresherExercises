<?php
require 'ProductDAO.php';
class ProductBUS
{
    
    public function __construct()
    {}
    public function insert(MyPDOConnect $conn, Product $pd) {
        $productDAO = new ProductDAO();
        $flag=$productDAO->insert($conn, $pd);
        if($flag == true){
            echo 'insert success';
        } else {
            echo 'insert not success';
        }
        $conn->closeConnection($conn);
    }
    public function update(MyPDOConnect $conn, Product $pd) {
        $productDAO = new ProductDAO();
        $flag=$productDAO->update($conn, $pd);
        if($flag == true){
            echo 'update success';
        } else {
            echo 'update not success';
        }
        $conn->closeConnection($conn);
    }
    public function delete(MyPDOConnect $conn, $id) {
        $productDAO = new ProductDAO();
        $flag=$productDAO->delete($conn, $id);
        if($flag == true){
            echo 'delete success';
        } else {
            echo 'delete not success';
        }
        $conn->closeConnection($conn);
    }
    public function getAllData(MyPDOConnect $conn) {
        $propers=array('*');
        $productDAO = new ProductDAO();
        $products=$productDAO->getDataNotWhere($conn,$propers);
        return $products;
    }
    public function getAllDataByWhere(MyPDOConnect $conn, $condition) {
        $propers=array('*');
        $productDAO = new ProductDAO();
        $products=$productDAO->getDataWhere($conn, $propers, $condition);
        return $products;
    }
}

