<?php

class MyPDOConnect
{
    private $localhost="localhost";
    private $db_name="db_product";
    private $username="root";
    private $password="";
    public function __construct(){
   
    }
    public function openConnection() {
        $conn=null;
        try {
            $conn=new PDO('mysql:host='.$this->localhost.';dbname='.$this->db_name, $this->username, $this->password);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
        return $conn;
    }
    public function closeConnection(PDO $conn) {
        $conn=null;
    }
}

