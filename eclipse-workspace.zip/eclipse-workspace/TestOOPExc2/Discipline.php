<?php

class Discipline
{
    private $id;
    private $name;
    private $numLectures;
    private $numExercises;
    private $idTeacher;
    public function __construct()
    {}
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @return mixed
     */
    public function getNumLectures()
    {
        return $this->numLectures;
    }

    /**
     * @return mixed
     */
    public function getNumExercises()
    {
        return $this->numExercises;
    }

    /**
     * @return mixed
     */
    public function getIdTeacher()
    {
        return $this->idTeacher;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @param mixed $numLectures
     */
    public function setNumLectures($numLectures)
    {
        $this->numLectures = $numLectures;
    }

    /**
     * @param mixed $numExercises
     */
    public function setNumExercises($numExercises)
    {
        $this->numExercises = $numExercises;
    }

    /**
     * @param mixed $idTeacher
     */
    public function setIdTeacher($idTeacher)
    {
        $this->idTeacher = $idTeacher;
    }

}

