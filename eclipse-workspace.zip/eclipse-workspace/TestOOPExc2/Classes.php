<?php

class Classes
{
    private $id;
    private $nameClass;
    public function __construct()
    {}
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getNameClass()
    {
        return $this->nameClass;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $nameClass
     */
    public function setNameClass($nameClass)
    {
        $this->nameClass = $nameClass;
    }

    
    
}

